# Resistor2
 
